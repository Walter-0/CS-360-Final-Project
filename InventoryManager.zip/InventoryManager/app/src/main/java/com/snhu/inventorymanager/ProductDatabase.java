package com.snhu.inventorymanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class ProductDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "products.db";
    private static final int VERSION = 1;

    private static ProductDatabase mProductDb;

    public enum ProductSortOrder { ALPHABETIC, QUANTITY_DESC, QUANTITY_ASC };

    public static ProductDatabase getInstance(Context context) {
        if (mProductDb == null) {
            mProductDb = new ProductDatabase(context);
        }
        return mProductDb;
    }

    public ProductDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class ProductTable {
        private static final String TABLE = "products";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_QUANTITY = "quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + ProductTable.TABLE + " (" +
                ProductTable.COL_ID + " integer primary key autoincrement, " +
                ProductTable.COL_NAME + " text, " +
                ProductTable.COL_QUANTITY + " int)");

        // Seed the database
        String[] productNames = {"Headphones", "Sweater", "Skateboard"};
        int[] productQuantities = {500, 350, 100};
        for (int i = 0; i < 3; i++) {
            Product product = new Product(productNames[i], productQuantities[i]);
            ContentValues values = new ContentValues();
            values.put(ProductTable.COL_NAME, product.getName());
            values.put(ProductTable.COL_QUANTITY, product.getQuantity());
            db.insert(ProductTable.TABLE, null, values);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + ProductTable.TABLE);
        onCreate(db);
    }

    public ArrayList<Product> getProducts(ProductSortOrder order) {
        ArrayList<Product> products = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String orderBy;

        switch (order) {
            case ALPHABETIC:
                orderBy = ProductTable.COL_NAME + " collate nocase";
                break;
            case QUANTITY_DESC:
                orderBy = ProductTable.COL_QUANTITY + " desc";
                break;
            default:
                orderBy = ProductTable.COL_QUANTITY + " asc";
                break;
        }

        String sql = "SELECT * FROM " + ProductTable.TABLE + " ORDER BY " + orderBy;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                Product product = new Product(cursor.getString(1), cursor.getInt(2));
                products.add(product);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return products;
    }

    public boolean addProduct(Product product) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ProductTable.COL_NAME, product.getName());
        values.put(ProductTable.COL_QUANTITY, product.getQuantity());
        long id = db.insert(ProductTable.TABLE, null, values);
        return id != -1;
    }

    public void updateProduct(Product product) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ProductTable.COL_NAME, product.getName());
        values.put(ProductTable.COL_QUANTITY, product.getQuantity());
        db.update(ProductTable.TABLE, values,
                ProductTable.COL_NAME + " = ?", new String[] { product.getName() });
    }

    public void deleteProduct(Product product) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(ProductTable.TABLE,
                ProductTable.COL_NAME + " = ?", new String[] { product.getName() });
    }
}
