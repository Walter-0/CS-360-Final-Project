package com.snhu.inventorymanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements SharedPreferences.OnSharedPreferenceChangeListener {

    private ProductDatabase mProductDb;
    private TextView mProductName;
    private TextView mProductQuantity;
    private EditText mNewProductNameEditText;
    private EditText mNewProductQuantityEditText;
    private EditText mEditProductQuantity;

    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if(checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {

        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mProductDb = ProductDatabase.getInstance(getApplicationContext());

        mProductName = findViewById(R.id.productName);
        mNewProductNameEditText = findViewById(R.id.newProductName);
        mNewProductQuantityEditText = findViewById(R.id.newProductQuantity);

        mListView = (ListView) findViewById(R.id.listView);
        ProductListAdapter adapter = new ProductListAdapter(this, R.layout.adapter_view_layout, loadProducts());
        mListView.setAdapter(adapter);

        setupSharedPreferences();
    }

    private void setupSharedPreferences() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        sharedPreferences.registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.settings_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        android.preference.PreferenceManager.getDefaultSharedPreferences(this).unregisterOnSharedPreferenceChangeListener(this);
    }

    private ArrayList<Product> loadProducts() {
        return mProductDb.getProducts(ProductDatabase.ProductSortOrder.ALPHABETIC);
    }

    public void addProduct(View view) {
        String newProductName = mNewProductNameEditText.getText().toString();
        int newProductQuantity = Integer.parseInt(mNewProductQuantityEditText.getText().toString());
        Product newProduct = new Product(newProductName, newProductQuantity);

        mProductDb.addProduct(newProduct);
    }

    public void deleteProduct(View view) {
        int position = mListView.getPositionForView(view);
        Product product = (Product) mListView.getItemAtPosition(position);
        mProductDb.deleteProduct(product);
    }

    public void stockProduct(View view) {
        int position = mListView.getPositionForView(view);
        Product product = (Product) mListView.getItemAtPosition(position);

        mEditProductQuantity = findViewById(R.id.editProductQuantity);
        mProductQuantity = findViewById(R.id.productQuantity);

        int productQuantityChange = Integer.parseInt(mEditProductQuantity.getText().toString());
        int oldQuantity = Integer.parseInt(mProductQuantity.getText().toString());
        int newQuantity = oldQuantity + productQuantityChange;
        product.setQuantity(newQuantity);

        mProductDb.updateProduct(product);
    }

    public void destockProduct(View view) {
        int position = mListView.getPositionForView(view);
        Product product = (Product) mListView.getItemAtPosition(position);

        mEditProductQuantity = findViewById(R.id.editProductQuantity);
        mProductQuantity = findViewById(R.id.productQuantity);

        int productQuantityChange = Integer.parseInt(mEditProductQuantity.getText().toString());
        int oldQuantity = Integer.parseInt(mProductQuantity.getText().toString());
        int newQuantity = oldQuantity - productQuantityChange;
        product.setQuantity(newQuantity);

        mProductDb.updateProduct(product);
    }
}
