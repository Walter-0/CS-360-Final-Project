package com.snhu.inventorymanager.data;

import com.snhu.inventorymanager.data.model.LoggedInUser;

import java.io.IOException;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {

    public Result<LoggedInUser> login(String username, String password) {

        try {
            if (username.equals("a@a.com") && password.equals("walter")) {
                LoggedInUser walter = new LoggedInUser("walter", "Walter");
                return new Result.Success<>(walter);
            }
            return null;
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public void logout() {
        // TODO: revoke authentication
    }
}
